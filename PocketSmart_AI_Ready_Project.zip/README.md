# PocketSmart AI — Your Smart Budget & Recommendation Assistant

## 1. Project overview
PocketSmart AI is a student-friendly personal budgeting web application. It records/reads transactions, summarizes income and expenses, visualizes spending categories, recommends category budgets, generates simple financial insights, and provides a what-if savings simulator.

The current version is deliberately local and API-free, so it can be demonstrated without paid AI services or API keys.

## 2. Features
- Dashboard for income, expenses, savings and savings rate
- CSV upload
- Category-wise spending chart
- Rule-based smart budget recommendations
- Personalized savings tips
- Savings-goal timeline estimate
- What-if simulator
- Demo dataset
- Responsive Streamlit interface

## 3. Technology
Python, Streamlit, Pandas, NumPy and Plotly.

## 4. Folder structure
```text
PocketSmart_AI/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── transactions.csv
├── docs/
│   └── PROJECT_DOCUMENTATION.md
└── assets/
```

## 5. Run on Windows
Install Python 3.10+.

```bash
cd PocketSmart_AI
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Open the URL shown by Streamlit, normally `http://localhost:8501`.

## 6. Run on Linux/macOS
```bash
cd PocketSmart_AI
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## 7. CSV format
Your CSV should contain:
`date, description, category, amount, type`

Example:
```csv
2026-09-01,Salary,Income,30000,Income
2026-09-02,Food,Food,2500,Expense
```

## 8. Demo flow
1. Start the app.
2. Show the dashboard cards.
3. Explain the category chart.
4. Show recommended category budgets.
5. Explain the AI-style recommendations.
6. Change the savings goal.
7. Move the what-if slider and show the new savings estimate.
8. Upload a CSV to demonstrate personalization.

## 9. Important note
This is an educational budgeting project. It does not connect to bank accounts and is not professional financial advice.
