
import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import plotly.express as px

st.set_page_config(page_title="PocketSmart AI", page_icon="💰", layout="wide")

BASE = Path(__file__).parent
DATA = BASE / "data" / "transactions.csv"

CATEGORIES = ["Food","Transport","Housing","Utilities","Education","Entertainment","Shopping","Health","Other"]

def load_data():
    return pd.read_csv(DATA, parse_dates=["date"])

def recommend(df, income, goal=0):
    exp = df[df["type"].eq("Expense")].copy()
    bycat = exp.groupby("category")["amount"].sum().sort_values(ascending=False)
    total = bycat.sum()
    recs = []
    for cat, amt in bycat.items():
        share = amt / total if total else 0
        if share >= 0.25:
            recs.append(f"Your {cat} spending is {share:.0%} of expenses. Consider setting a monthly limit near ₹{amt*0.85:,.0f}.")
        elif share >= 0.15:
            recs.append(f"{cat} is a major spending area at {share:.0%}. A small reduction could improve your monthly savings.")
    savings = income - total
    if savings < 0:
        recs.append("Expenses are above income in this sample. Prioritize essential bills and reduce flexible spending.")
    elif income and savings/income < 0.20:
        recs.append(f"Your current savings rate is {savings/income:.0%}. A practical target could be 20% of monthly income.")
    else:
        recs.append(f"Estimated savings are ₹{savings:,.0f}. Keep a separate emergency/savings allocation.")
    if goal > 0:
        months = goal/savings if savings > 0 else None
        recs.append(f"To reach a ₹{goal:,.0f} goal, estimated time is about {months:.1f} months." if months else "Increase monthly savings before estimating the goal timeline.")
    return recs, bycat, total, savings

st.title("💰 PocketSmart AI")
st.caption("Your Smart Budget & Recommendation Assistant — educational demo project")

with st.sidebar:
    st.header("Controls")
    uploaded = st.file_uploader("Upload transactions CSV", type=["csv"])
    income = st.number_input("Monthly income (₹)", min_value=0.0, value=30000.0, step=1000.0)
    goal = st.number_input("Savings goal (₹)", min_value=0.0, value=10000.0, step=1000.0)
    if st.button("Reset to demo data"):
        st.rerun()

df = pd.read_csv(uploaded, parse_dates=["date"]) if uploaded is not None else load_data()
required = {"date","description","category","amount","type"}
if not required.issubset(df.columns):
    st.error("CSV must contain: date, description, category, amount, type")
    st.stop()

expenses = df[df["type"].str.lower().eq("expense")].copy()
income_rows = df[df["type"].str.lower().eq("income")].copy()
expense_total = expenses["amount"].sum()
income_from_file = income_rows["amount"].sum()
effective_income = income if income > 0 else income_from_file
balance = effective_income - expense_total
savings_rate = balance/effective_income if effective_income else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Monthly Income", f"₹{effective_income:,.0f}")
c2.metric("Expenses", f"₹{expense_total:,.0f}")
c3.metric("Balance / Savings", f"₹{balance:,.0f}")
c4.metric("Savings Rate", f"{savings_rate:.0%}")

st.divider()
left,right = st.columns(2)
with left:
    st.subheader("Spending by Category")
    cat = expenses.groupby("category", as_index=False)["amount"].sum().sort_values("amount", ascending=False)
    fig = px.pie(cat, names="category", values="amount", hole=.45)
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Budget Recommendation")
    recs, bycat, total, savings = recommend(expenses, effective_income, goal)
    budget = (bycat * 0.90).round(0).reset_index()
    budget.columns = ["category","recommended_budget"]
    st.dataframe(budget, use_container_width=True, hide_index=True)
    for r in recs:
        st.info("🤖 " + r)

st.subheader("Recent Transactions")
st.dataframe(df.sort_values("date", ascending=False).head(20), use_container_width=True, hide_index=True)

st.subheader("What-If Savings Simulator")
cut = st.slider("Reduce flexible spending by", 0, 40, 10, 5)
flex = expenses[expenses["category"].isin(["Food","Entertainment","Shopping","Transport"])]["amount"].sum()
new_savings = balance + flex*(cut/100)
st.success(f"If flexible spending falls by {cut}%, estimated monthly savings become ₹{new_savings:,.0f}.")

st.caption("Educational project only. Recommendations are simple rule-based suggestions, not professional financial advice.")
