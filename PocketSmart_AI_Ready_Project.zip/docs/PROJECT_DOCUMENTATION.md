# PocketSmart AI — Project Documentation

## Abstract
PocketSmart AI is a web-based smart budgeting assistant designed to help users understand monthly income and expenses. The system processes transaction records, groups expenses into categories, calculates savings, visualizes spending, and produces simple personalized recommendations. It is designed as an academic project demonstrating Python, data analysis, visualization, web development and rule-based AI.

## Problem Statement
Many students and young users record expenses but do not easily understand where their money goes. Manual calculations make it difficult to compare categories, set realistic budgets and estimate savings. PocketSmart AI provides a simple dashboard that converts transaction data into understandable financial information.

## Objectives
1. Track income and expenses.
2. Calculate remaining balance and savings rate.
3. Analyze category-wise spending.
4. Recommend simple budget limits from spending history.
5. Provide personalized spending suggestions.
6. Simulate how reduced flexible spending affects savings.
7. Accept user CSV data for demonstration.

## Proposed System
The application follows this flow:

User/CSV → Data validation → Expense categorization → Financial calculations → Visualization → Recommendation engine → What-if simulator

## Modules
### 1. Data Input
Users can use the built-in sample CSV or upload a CSV.

### 2. Financial Calculator
Calculates:
- Total income
- Total expenses
- Balance
- Savings rate

Formula:
`Balance = Income - Expenses`

`Savings Rate = Balance / Income × 100`

### 3. Analytics
Pandas groups transactions by category. Plotly displays the category distribution.

### 4. Recommendation Engine
The current prototype uses transparent rules:
- If a category is ≥25% of total expenses, suggest a reduction.
- If savings rate is below 20%, suggest increasing savings.
- If expenses exceed income, flag the deficit.
- If a savings goal is supplied, estimate months using `goal / monthly savings`.

### 5. What-If Simulator
Flexible spending is defined as Food, Entertainment, Shopping and Transport. The user selects a reduction percentage and the app estimates the resulting monthly savings.

## Software Requirements
- Python 3.10 or later
- Web browser
- Internet only for initial package installation

## Hardware Requirements
- 4 GB RAM minimum
- Dual-core processor
- 500 MB free disk space for the project and Python packages

## Database
The demo version uses CSV for portability. A future version can use SQLite/PostgreSQL for user accounts and persistent transaction storage.

## AI Component
The prototype uses an explainable rule-based recommendation engine, which is appropriate for a classroom demonstration because every recommendation can be traced to a simple condition. A future version can add a machine-learning model for expense categorization or an LLM assistant.

## Security and Privacy
No bank login or bank credentials are collected. Uploaded transaction data is processed locally by the Streamlit session. Users should avoid uploading real account numbers or other sensitive information to a classroom demo.

## Testing
### Test case 1
Income ₹30,000 and expenses below ₹30,000 → positive balance.

### Test case 2
Upload valid CSV → dashboard recalculates.

### Test case 3
Upload CSV without required columns → validation error.

### Test case 4
Savings goal entered → estimated goal duration appears when monthly savings are positive.

### Test case 5
Move what-if slider → estimated savings changes.

## Expected Output
The dashboard should display:
- Income
- Expenses
- Balance
- Savings rate
- Spending chart
- Recommended category budgets
- Personalized tips
- Transaction table
- What-if savings result

## Future Enhancements
- Login and registration
- SQLite database
- Receipt OCR
- ML-based transaction classification
- Monthly forecasting
- Bill reminders
- PDF reports
- Tamil/English language support
- Optional LLM chatbot
- Mobile deployment

## Conclusion
PocketSmart AI demonstrates how data processing, visualization and explainable AI rules can be combined into a practical budgeting assistant. The project is small enough for a college demonstration while leaving clear paths for advanced AI/ML extensions.
