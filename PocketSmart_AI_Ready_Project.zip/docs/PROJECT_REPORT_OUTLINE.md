# College Project Report Outline

1. Title Page
2. Certificate
3. Declaration
4. Acknowledgement
5. Abstract
6. Introduction
7. Existing System
8. Proposed System
9. Problem Statement
10. Objectives
11. System Requirements
12. System Architecture
13. Module Description
14. Algorithms and Formulas
15. Implementation
16. Screenshots
17. Testing
18. Results
19. Advantages
20. Limitations
21. Future Enhancements
22. Conclusion
23. References

### Suggested title
PocketSmart AI: Your Smart Budget & Recommendation Assistant

### Suggested viva questions
1. Why did you choose Streamlit?
2. What is the difference between income and expense?
3. How is savings rate calculated?
4. How does the recommendation engine work?
5. Why is explainable AI useful in finance?
6. Why is CSV used in the prototype?
7. How would you add machine learning?
8. What security concerns exist in financial applications?
